"""
Author: Adam Forte
Class: COP 1000
Date: 5/4/20

Purpose: Runs in two modse.
Encryption mode: Should encrypt information from a text file through simple
cyphers.
Decrpytion mode: should take in information from a text file, recieve parameters
for decryption and decrypt.
"""
import random
import math
"""
mode = '1'#input("press '1' for encrypt or '2' for decrypt> ")
notFile = 'Test.txt'#input("Input a file> ")
file = open(notFile, 'r')
words = file.read()
wordLyst = words.split()
"""
#works; run first on encryption mode
def insertSpace(lyst):
    """Inserts spaces between characters of all items in a list of strings,
    and returns the result as lists within a list."""
    for word in range(len(lyst)):
        count = -1
        workingWord = list(lyst[word])
        for letters in range(len(workingWord) * 2): 
            count += 1
            if letters % 2 == 1 and letters >= 1:          
                workingWord.insert(count, ' ')
        workingWordStr = ""
        for item in range(len(workingWord)):
            workingWordStr += workingWord[item]
        lyst[word] = workingWord
    return(lyst)

#works; use second on encryption mode
def numbr(lyst):
    """converst characters of multiple lists to integers"""
    for word in range(len(lyst)):
        workingWord = lyst[word]
        for letter in range(len(workingWord)):
            if letter % 2 == 0:
                workingWord[letter] = ord(workingWord[letter])
        lyst[word] = workingWord
    return(lyst)

#works use third on encryption mode
def expEncrypt(lyst):
    """Raises all values of the lists to a randomized power, copied to another text file"""
    #first couple lines save the random exponent to the 
    newFile = "decryption_codes_for_"
    newFile += notFile
    valuesFile = open(newFile, 'w')
    exponent = random.randint(1,5)
    valuesFile.write(str(exponent))
    valuesFile.close()
    for word in range(len(lyst)):
        workingWord = lyst[word]
        for letter in range(len(workingWord)):
            if letter % 2 == 0:
                workingWord[letter] = workingWord[letter] ** exponent
        lyst[word] = workingWord
    return(lyst)

#works; use fourth on encryption mode
def multEncrypt(lyst):
    """Multiplies all values in the list by a random number, copied to another text file"""

    coef = random.randint(1,100)
    newFile = "decryption_codes_for_"
    newFile += notFile
    valuesFileR = open(newFile, 'r')
    txt = valuesFileR.read()
    txt += " "
    txt += str(coef)
    valuesFileR.close()
    valuesFileW = open(newFile, 'w')
    valuesFileW.write(txt)
    valuesFileW.close()

    for word in range(len(lyst)):
        workingWord = lyst[word]
        for letter in range(len(workingWord)):
            if letter % 2 == 0:
                workingWord[letter] = workingWord[letter] * coef
        lyst[word] = workingWord
    return(lyst)

#works; use last on encryption mode
def writeEncrypt(lyst):
    """Converts integers in list to strings, and copies them to a newly created file."""
    for word in range(len(lyst)):
        workingWord = lyst[word]
        for letter in range(len(workingWord)):
            if letter % 2 == 0:
                workingWord[letter] = str(workingWord[letter])
        lyst[word] = workingWord

    txt = ""
    for word in range(len(lyst)):
        workingWord = lyst[word]
        for letter in range(len(workingWord)):
            txt += workingWord[letter]
        txt += '\n'
        lyst[word] = workingWord
    newFile = "encrypted_"
    newFile += notFile
    f = open(newFile, 'w')
    f.write(txt)
    f.close()
    return

def encrypt(lyst):
    insertSpace(lyst)
    numbr(lyst)
    expEncrypt(lyst)
    multEncrypt(lyst)
    writeEncrypt(lyst)
    print("...Done")

def divDecrypt(lyst, coef):
    for word in range(len(lyst)):
        lyst[word] = lyst[word].split()
        workingWord = lyst[word]
        for letter in range(len(workingWord)):
            workingWord[letter] = int(workingWord[letter])
    for word in range(len(lyst)):
        workingWord = lyst[word]
        for letter in range(len(workingWord)):
            workingWord[letter] = workingWord[letter] / coef
        lyst[word] = workingWord   
    return lyst

def rootDecrypt(lyst, pwr):
    for word in range(len(lyst)):
        workingWord = lyst[word]
        for letter in range(len(workingWord)):
            workingWord[letter] = int(workingWord[letter] ** (1 / pwr))
        lyst[word] = workingWord   
    return lyst

def lettr(lyst):
    for word in range(len(lyst)):
        workingWord = lyst[word]
        for letter in range(len(workingWord)):
            workingWord[letter] = chr(workingWord[letter])
        lyst[word] = workingWord
    print(lyst)
    return(lyst)

def writeDecrypt(lyst):
    txt = ""
    for word in range(len(lyst)):
        workingWord = lyst[word]
        for letter in range(len(workingWord)):
            txt += workingWord[letter]
        txt += ' '
        lyst[word] = workingWord
    newFile = "decrypted_"
    newFile += notFile
    f = open(newFile, 'w')
    f.write(txt)
    f.close()
    return
def decrypt(lyst, coef, pwr):
    divDecrypt(wordLyst, coef)
    rootDecrypt(wordLyst, pwr)
    lettr(wordLyst)
    writeDecrypt(wordLyst)

while True:    
    mode = input("press '1' for encrypt or '2' for decrypt> ")
    if mode == '1':
        notFile = input("Input a file> ")
        file = open(notFile, 'r')
        words = file.read()
        wordLyst = words.split()
        encrypt(wordLyst)
        break
    
    elif mode == '2':
        root = int(input("Enter first encryption code> "))
        div = int(input("Enter second encryption code> "))
        notFile = input("Input a file> ")
        file = open(notFile, 'r')
        words = file.read()
        wordLyst = words.split('\n')
        decrypt(wordLyst, div, root)
        print("...Done")
        break
    
    else:
        print("invalid input")





















