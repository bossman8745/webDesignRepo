This program is a very simple encryption/decryption program. To encrypt a file, press 1 when prompted to 
select mode, and then enter the text file you wish to encrypt. This will create a separate text file with 
the coded text, as well as two numbers that can be used to decrypt it in the decryption mode. To use the 
decryption mode, press 2 when prompted, followed by each individual number copied in the decryption codes
file. IMPORTANT: enter each of these numbers separatel; there are two prompts. Finally, enter the file you
want decrypted. This will create a new file with the decrypted text.